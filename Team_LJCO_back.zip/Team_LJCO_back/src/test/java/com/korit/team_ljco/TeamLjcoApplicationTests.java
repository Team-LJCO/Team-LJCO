package com.korit.team_ljco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamLjcoApplicationTests {

	@Test
	void contextLoads() {
	}

}
