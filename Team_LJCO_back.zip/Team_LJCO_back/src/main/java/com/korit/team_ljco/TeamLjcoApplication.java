package com.korit.team_ljco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamLjcoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamLjcoApplication.class, args);
	}

}
